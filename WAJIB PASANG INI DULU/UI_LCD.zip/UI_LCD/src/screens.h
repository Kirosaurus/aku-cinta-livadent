#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

// Screens

enum ScreensEnum {
    _SCREEN_ID_FIRST = 1,
    SCREEN_ID_WIFI_SETTINGS = 1,
    SCREEN_ID_SPLASH_SCREEN = 2,
    SCREEN_ID_MAIN_MENU = 3,
    SCREEN_ID_SCREENING = 4,
    SCREEN_ID_RESULT = 5,
    SCREEN_ID_EMERGENCY_STOP = 6,
    SCREEN_ID_VISC_CALIBRATION = 7,
    SCREEN_ID_CALIBRATION_MENU = 8,
    SCREEN_ID_PH_CALIBRATION = 9,
    _SCREEN_ID_LAST = 9
};

typedef struct _objects_t {
    lv_obj_t *wifi_settings;
    lv_obj_t *splash_screen;
    lv_obj_t *main_menu;
    lv_obj_t *screening;
    lv_obj_t *result;
    lv_obj_t *emergency_stop;
    lv_obj_t *visc_calibration;
    lv_obj_t *calibration_menu;
    lv_obj_t *ph_calibration;
    lv_obj_t *head;
    lv_obj_t *wifi_indicator_settings;
    lv_obj_t *obj0;
    lv_obj_t *wifi_status_settings;
    lv_obj_t *wifi_ssid_settings;
    lv_obj_t *body;
    lv_obj_t *obj1;
    lv_obj_t *wifi_list;
    lv_obj_t *current_page_pagination;
    lv_obj_t *wifi_page_prev_btn;
    lv_obj_t *wifi_page_next_btn;
    lv_obj_t *wifi_status;
    lv_obj_t *back_wifi_btn;
    lv_obj_t *disconnect_wifi_btn;
    lv_obj_t *panel_input_wifi_password;
    lv_obj_t *name_ssid;
    lv_obj_t *connection_status;
    lv_obj_t *textarea_password;
    lv_obj_t *hide_password_btn;
    lv_obj_t *is_auto_connect;
    lv_obj_t *cancel_btn;
    lv_obj_t *connect_wifi_btn;
    lv_obj_t *keyboard_password;
    lv_obj_t *panel_status_connection;
    lv_obj_t *wifi_spinner;
    lv_obj_t *wifi_success;
    lv_obj_t *wifi_failed;
    lv_obj_t *status_connection;
    lv_obj_t *detail_status_wifi_connection;
    lv_obj_t *wifi_ssid_status_connection;
    lv_obj_t *process_init;
    lv_obj_t *head_3;
    lv_obj_t *obj2;
    lv_obj_t *body_3;
    lv_obj_t *wifi_indicator_home;
    lv_obj_t *wifi_status_home;
    lv_obj_t *wifi_ssid_home;
    lv_obj_t *web_app;
    lv_obj_t *web_app_indicator_home;
    lv_obj_t *web_app_status_home;
    lv_obj_t *web_app_home;
    lv_obj_t *is_prototype_ready_container_1;
    lv_obj_t *is_prototype_ready_container;
    lv_obj_t *is_prototype_ready_indicator;
    lv_obj_t *is_prototype_ready_label;
    lv_obj_t *mulai_btn;
    lv_obj_t *mulai_text;
    lv_obj_t *pengaturan_wifi_btn;
    lv_obj_t *offline_warning;
    lv_obj_t *obj3;
    lv_obj_t *obj4;
    lv_obj_t *continue_offline_screening;
    lv_obj_t *back_offline_screening;
    lv_obj_t *obj5;
    lv_obj_t *head_5;
    lv_obj_t *wifi_indicator_screening;
    lv_obj_t *offline_indicator_screening;
    lv_obj_t *obj6;
    lv_obj_t *wifi_detail_status_screening;
    lv_obj_t *obj7;
    lv_obj_t *wifi_status_screening;
    lv_obj_t *wifi_ssid_screening;
    lv_obj_t *body_5;
    lv_obj_t *container_peringatan_penggunaan;
    lv_obj_t *obj8;
    lv_obj_t *screening_on_progress;
    lv_obj_t *screening_failed;
    lv_obj_t *obj9;
    lv_obj_t *container_screening_btn;
    lv_obj_t *back_btn_screening;
    lv_obj_t *start_stop_screening_btn;
    lv_obj_t *start_stop_screening_label;
    lv_obj_t *arrow_start_screening;
    lv_obj_t *back_in_second;
    lv_obj_t *failed_back_to_main_menu_btn;
    lv_obj_t *failed_timeout_second;
    lv_obj_t *head_7;
    lv_obj_t *wifi_indicator_result;
    lv_obj_t *offline_indicator_result;
    lv_obj_t *obj10;
    lv_obj_t *wifi_detail_status_result;
    lv_obj_t *obj11;
    lv_obj_t *wifi_status_result;
    lv_obj_t *wifi_ssid_result;
    lv_obj_t *body_2;
    lv_obj_t *ph_icon;
    lv_obj_t *ph_warning;
    lv_obj_t *ph_value;
    lv_obj_t *visc_icon;
    lv_obj_t *visc_warning;
    lv_obj_t *visc_value;
    lv_obj_t *risk_bg;
    lv_obj_t *risk_indicator;
    lv_obj_t *risk_label;
    lv_obj_t *risk_desc;
    lv_obj_t *result_done_btn;
    lv_obj_t *head_4;
    lv_obj_t *obj12;
    lv_obj_t *body_4;
    lv_obj_t *obj13;
    lv_obj_t *obj14;
    lv_obj_t *head_6;
    lv_obj_t *obj15;
    lv_obj_t *body_6;
    lv_obj_t *calibration_visc_text_info;
    lv_obj_t *calibration_value_info_container;
    lv_obj_t *value_info;
    lv_obj_t *container_calibration_btn;
    lv_obj_t *back_btn_visc_calibration;
    lv_obj_t *start_btn_visc_calibration;
    lv_obj_t *start_stop_screening_label_1;
    lv_obj_t *arrow_start_screening_1;
    lv_obj_t *panel_status_calibration_visc;
    lv_obj_t *calibration_success;
    lv_obj_t *status_connection_1;
    lv_obj_t *calibration_status_info;
    lv_obj_t *head_8;
    lv_obj_t *obj16;
    lv_obj_t *body_7;
    lv_obj_t *calibration_text_info_1;
    lv_obj_t *ph_calibrate_option;
    lv_obj_t *visc_calibrate_option;
    lv_obj_t *calibration_value_info_container_1;
    lv_obj_t *value_info_1;
    lv_obj_t *container_calibration;
    lv_obj_t *back_btn_menu_calibration;
    lv_obj_t *head_9;
    lv_obj_t *obj17;
    lv_obj_t *body_8;
    lv_obj_t *calibration_text_info_ph;
    lv_obj_t *calibration_value_info_container_ph;
    lv_obj_t *value_info_2;
    lv_obj_t *container_calibration_btn_ph;
    lv_obj_t *back_btn_screening_3;
    lv_obj_t *start_stop_screening_btn_2;
    lv_obj_t *start_stop_screening_label_2;
    lv_obj_t *arrow_start_screening_2;
    lv_obj_t *panel_status_calibration_ph;
    lv_obj_t *calibration_success_1;
    lv_obj_t *status_connection_2;
    lv_obj_t *calibration_status_info_1;
} objects_t;

extern objects_t objects;

void create_screen_wifi_settings();
void tick_screen_wifi_settings();

void create_screen_splash_screen();
void tick_screen_splash_screen();

void create_screen_main_menu();
void tick_screen_main_menu();

void create_screen_screening();
void tick_screen_screening();

void create_screen_result();
void tick_screen_result();

void create_screen_emergency_stop();
void tick_screen_emergency_stop();

void create_screen_visc_calibration();
void tick_screen_visc_calibration();

void create_screen_calibration_menu();
void tick_screen_calibration_menu();

void create_screen_ph_calibration();
void tick_screen_ph_calibration();

void tick_screen_by_id(enum ScreensEnum screenId);
void tick_screen(int screen_index);

void create_screens();

#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/