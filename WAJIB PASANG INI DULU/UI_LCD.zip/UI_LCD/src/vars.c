#include "vars.h"

bool is_web_connected;

bool get_var_is_web_connected() {
    return is_web_connected;
}

void set_var_is_web_connected(bool value) {
    is_web_connected = value;
}