#ifndef EEZ_LVGL_UI_IMAGES_H
#define EEZ_LVGL_UI_IMAGES_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

extern const lv_img_dsc_t img_no_connection;
extern const lv_img_dsc_t img_connected;
extern const lv_img_dsc_t img_livadent;
extern const lv_img_dsc_t img_no_connection_red;
extern const lv_img_dsc_t img_connected_black;
extern const lv_img_dsc_t img_no_web_app;
extern const lv_img_dsc_t img_default_student;
extern const lv_img_dsc_t img_high_risk;
extern const lv_img_dsc_t img_low_risk;
extern const lv_img_dsc_t img_medium_risk;
extern const lv_img_dsc_t img_screening_on_progress;
extern const lv_img_dsc_t img_web_app;
extern const lv_img_dsc_t img_waiting_web_app;
extern const lv_img_dsc_t img_web_app_ready;
extern const lv_img_dsc_t img_arrow_mulai_screening;
extern const lv_img_dsc_t img_wifi_success;
extern const lv_img_dsc_t img_wifi_failed;
extern const lv_img_dsc_t img_splash_screen;
extern const lv_img_dsc_t img_eye_hide;
extern const lv_img_dsc_t img_eye;
extern const lv_img_dsc_t img_ph;
extern const lv_img_dsc_t img_viscosity;

#ifndef EXT_IMG_DESC_T
#define EXT_IMG_DESC_T
typedef struct _ext_img_desc_t {
    const char *name;
    const lv_img_dsc_t *img_dsc;
} ext_img_desc_t;
#endif

extern const ext_img_desc_t images[22];

#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_IMAGES_H*/