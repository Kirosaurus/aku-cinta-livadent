#include "actions.h"
#include "screens.h"
#include "ui.h"

void action_hide_ssid_password_input_panel(lv_event_t *e) {
    lv_textarea_set_text(objects.textarea_password, "");
    lv_obj_add_flag(objects.panel_input_wifi_password, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(objects.keyboard_password, LV_OBJ_FLAG_HIDDEN);
}